"""
PyCryptX - Secure Text & File Encryption Toolkit

Educational portfolio project using:
- PBKDF2-HMAC-SHA256 for password-based key derivation
- AES-256-GCM for authenticated encryption

The program can encrypt/decrypt text and files.
"""

import base64
import getpass
import hashlib
import json
import os
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

MAGIC = b"PYCRYPTX1"
SALT_SIZE = 16
NONCE_SIZE = 12
KEY_SIZE = 32
PBKDF2_ITERATIONS = 600_000


def derive_key(password: str, salt: bytes) -> bytes:
    """Derive a 256-bit key from a password and random salt."""
    if not password:
        raise ValueError("Password cannot be empty.")

    return hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        PBKDF2_ITERATIONS,
        dklen=KEY_SIZE,
    )


def encrypt_bytes(data: bytes, password: str) -> bytes:
    """Encrypt bytes using AES-256-GCM."""
    salt = os.urandom(SALT_SIZE)
    nonce = os.urandom(NONCE_SIZE)
    key = derive_key(password, salt)

    ciphertext = AESGCM(key).encrypt(nonce, data, MAGIC)

    # Format:
    # MAGIC | salt | nonce | ciphertext+authentication-tag
    return MAGIC + salt + nonce + ciphertext


def decrypt_bytes(payload: bytes, password: str) -> bytes:
    """Decrypt and authenticate encrypted bytes."""
    minimum_size = len(MAGIC) + SALT_SIZE + NONCE_SIZE + 16

    if len(payload) < minimum_size:
        raise ValueError("Invalid or incomplete encrypted data.")

    if payload[:len(MAGIC)] != MAGIC:
        raise ValueError("This file was not created by PyCryptX.")

    offset = len(MAGIC)
    salt = payload[offset:offset + SALT_SIZE]
    offset += SALT_SIZE

    nonce = payload[offset:offset + NONCE_SIZE]
    offset += NONCE_SIZE

    ciphertext = payload[offset:]
    key = derive_key(password, salt)

    try:
        return AESGCM(key).decrypt(nonce, ciphertext, MAGIC)
    except Exception as exc:
        raise ValueError(
            "Decryption failed. The password may be incorrect "
            "or the data may have been modified."
        ) from exc


def encrypt_text():
    print("\n--- Encrypt Text ---")
    message = input("Enter text: ")

    if not message:
        print("Text cannot be empty.")
        return

    password = getpass.getpass("Password: ")

    try:
        encrypted = encrypt_bytes(message.encode("utf-8"), password)
        encoded = base64.urlsafe_b64encode(encrypted).decode("ascii")

        print("\nEncrypted text:")
        print(encoded)
        print("\nKeep this encrypted text and password safe.")
    except ValueError as exc:
        print(f"Error: {exc}")


def decrypt_text():
    print("\n--- Decrypt Text ---")
    encoded = input("Paste encrypted text: ").strip()

    if not encoded:
        print("Encrypted text cannot be empty.")
        return

    password = getpass.getpass("Password: ")

    try:
        payload = base64.urlsafe_b64decode(encoded.encode("ascii"))
        plaintext = decrypt_bytes(payload, password)
        print("\nDecrypted message:")
        print(plaintext.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        print(f"Error: {exc}")


def encrypt_file():
    print("\n--- Encrypt File ---")
    source = Path(input("Input file path: ").strip())

    if not source.is_file():
        print("Input file does not exist.")
        return

    password = getpass.getpass("Password: ")
    output = Path(str(source) + ".pcrypt")

    try:
        data = source.read_bytes()
        encrypted = encrypt_bytes(data, password)
        output.write_bytes(encrypted)

        print(f"\nFile encrypted successfully:")
        print(output)
    except OSError as exc:
        print(f"File error: {exc}")
    except ValueError as exc:
        print(f"Error: {exc}")


def decrypt_file():
    print("\n--- Decrypt File ---")
    source = Path(input("Encrypted .pcrypt file: ").strip())

    if not source.is_file():
        print("Encrypted file does not exist.")
        return

    password = getpass.getpass("Password: ")

    if source.suffix.lower() == ".pcrypt":
        output = source.with_suffix("")
    else:
        output = Path(str(source) + ".decrypted")

    try:
        encrypted = source.read_bytes()
        decrypted = decrypt_bytes(encrypted, password)
        output.write_bytes(decrypted)

        print(f"\nFile decrypted successfully:")
        print(output)
    except (OSError, ValueError) as exc:
        print(f"Error: {exc}")


def show_about():
    print("""
PyCryptX
--------
A Python educational cryptography toolkit.

Encryption:
    AES-256-GCM

Key derivation:
    PBKDF2-HMAC-SHA256

Password salt:
    16 random bytes

Nonce:
    12 random bytes

Key:
    256 bits

PBKDF2 iterations:
    600,000

AES-GCM provides confidentiality and authentication,
so modified encrypted data should fail verification.
""")


def main():
    while True:
        print("""
╔════════════════════════════════════════════╗
║              PYCRYPTX v1.0                 ║
║      Secure Text & File Encryption         ║
╠════════════════════════════════════════════╣
║ 1. Encrypt text                            ║
║ 2. Decrypt text                            ║
║ 3. Encrypt file                            ║
║ 4. Decrypt file                            ║
║ 5. About / security details                ║
║ 6. Exit                                    ║
╚════════════════════════════════════════════╝
""")

        choice = input("Choose an option: ").strip()

        if choice == "1":
            encrypt_text()
        elif choice == "2":
            decrypt_text()
        elif choice == "3":
            encrypt_file()
        elif choice == "4":
            decrypt_file()
        elif choice == "5":
            show_about()
        elif choice == "6":
            print("\nThank you for using PyCryptX!")
            break
        else:
            print("\nInvalid choice. Please select 1-6.")


if __name__ == "__main__":
    main()

This folder is for test files.

Example:
1. Create notes.txt here.
2. Run PyCryptX.
3. Choose file encryption.
4. Encrypt notes.txt.
5. Test decryption.

Do not put passwords, API keys, or real sensitive information in this repository.

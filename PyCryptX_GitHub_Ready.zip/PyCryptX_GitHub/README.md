# PyCryptX 🔐

## Secure Text & File Encryption Toolkit

**PyCryptX** is a Python-based cryptography project for encrypting and decrypting text and files using modern authenticated encryption.

The project uses **AES-256-GCM** for encryption and **PBKDF2-HMAC-SHA256** to derive a 256-bit encryption key from a user password.

This makes the project more practical than a simple Caesar cipher or XOR demonstration and provides a good introduction to modern cryptographic concepts.

> **Important:** PyCryptX is an educational portfolio project. For highly sensitive or production-critical information, use a professionally audited cryptographic application and secure key-management system.

## ✨ Features

- Encrypt text
- Decrypt text
- Encrypt files
- Decrypt files
- AES-256-GCM authenticated encryption
- Password-based key derivation
- PBKDF2-HMAC-SHA256
- Random salt for every encryption operation
- Random nonce for every encryption operation
- Authentication/integrity verification
- Password input is hidden in the terminal
- Original files are not overwritten
- Simple command-line interface
- Clear error messages

## 🛠️ Technologies

- Python 3.8+
- `cryptography`
- AES-256-GCM
- PBKDF2-HMAC-SHA256
- Base64
- `pathlib`
- Secure random generation with `os.urandom`

## 📁 Project Structure

```text
PyCryptX/
│
├── pycryptx.py
├── README.md
├── requirements.txt
├── .gitignore
└── sample_files/
    └── README.txt
```

## ⚙️ Installation

Install Python 3.8 or newer.

Then install the dependency:

```bash
pip install -r requirements.txt
```

Or:

```bash
pip install cryptography
```

## ▶️ Run

```bash
python pycryptx.py
```

The program displays:

```text
1. Encrypt text
2. Decrypt text
3. Encrypt file
4. Decrypt file
5. About / security details
6. Exit
```

## 🔒 Text Encryption Example

Select:

```text
1. Encrypt text
```

Enter:

```text
Enter text: Hello from PyCryptX!
Password: ********
```

The application produces a Base64-encoded encrypted payload.

The encrypted text is safe to store or transfer, but the password must be kept separately.

## 🔓 Text Decryption

Select:

```text
2. Decrypt text
```

Paste the encrypted payload and enter the same password.

If the password and data are correct, the original text is recovered.

## 📄 File Encryption

Select:

```text
3. Encrypt file
```

Example:

```text
Input file path: sample_files/notes.txt
Password: ********
```

PyCryptX creates:

```text
sample_files/notes.txt.pcrypt
```

The original `notes.txt` is not modified.

## 📄 File Decryption

Select:

```text
4. Decrypt file
```

Example:

```text
Encrypted .pcrypt file: sample_files/notes.txt.pcrypt
Password: ********
```

The original filename is restored:

```text
sample_files/notes.txt
```

## 🧠 Cryptography Explained

### AES-256-GCM

AES is a symmetric encryption algorithm.

The same secret key is used for encryption and decryption.

PyCryptX uses a **256-bit AES key** with **GCM mode**.

GCM provides:

- Confidentiality
- Authentication
- Integrity checking

Therefore, if encrypted data is modified, decryption should fail.

### PBKDF2

Users normally remember passwords rather than random 256-bit keys.

PyCryptX uses:

```text
PBKDF2-HMAC-SHA256
```

to convert the password into a cryptographic key.

A random salt is generated for each encryption operation.

### Salt

The salt makes password-derived keys unique between encryption operations.

It is not a secret and is stored with the encrypted data.

### Nonce

AES-GCM requires a nonce.

PyCryptX generates a fresh random 12-byte nonce for every encryption operation.

The nonce does not need to be secret, but it must not be reused with the same key.

## 🔐 Encrypted Data Format

PyCryptX stores encrypted data as:

```text
MAGIC
  +
SALT
  +
NONCE
  +
CIPHERTEXT
  +
AUTHENTICATION TAG
```

This allows the program to recover the parameters needed for decryption while keeping the password secret.

## 🛡️ Security Considerations

PyCryptX does **not** store passwords.

A wrong password or modified ciphertext causes authentication failure.

However:

- Never share your password with the encrypted file.
- Do not hard-code passwords into source code.
- Do not commit real secrets to GitHub.
- Keep backups of important files.
- Use a password manager for strong unique passwords.
- Production systems should use audited key-management practices.

## 🎓 Concepts Demonstrated

This project demonstrates:

- Symmetric encryption
- AES
- Authenticated encryption
- AES-GCM
- Password-based key derivation
- PBKDF2
- SHA-256
- Salt
- Nonce
- Authentication tags
- Binary data
- Base64 encoding
- File handling
- Exception handling
- Secure password input
- CLI application design

## 🚀 Future Improvements

Possible extensions:

- Graphical interface using Tkinter
- Password strength meter
- Secure password generation
- Multi-file encryption
- Encrypted ZIP archives
- Key-file support
- Secure key storage
- Encryption metadata
- Unit tests
- Automated CI testing
- Secure deletion workflow

## ⚠️ Disclaimer

This project is intended for **education, learning, and portfolio demonstration**.

It is not a replacement for professional cryptographic software, audited libraries, enterprise key-management systems, or security engineering practices.

## 🎯 Project Objective

The objective of PyCryptX is to demonstrate practical Python programming together with fundamental modern cryptography concepts.

It shows how passwords can be transformed into encryption keys and how authenticated encryption can protect both the confidentiality and integrity of data.

## 👨‍💻 Author

**Subhadip**

Python | Cryptography | Cybersecurity Fundamentals
